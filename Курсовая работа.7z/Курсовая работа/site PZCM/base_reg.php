<?php 
    $host="localhost"; 
    $user="root"; 
    $password="";
	$database="pzcm";	
	$admin = array("login" => "sysdba", "password" => "masterkey");
?> 