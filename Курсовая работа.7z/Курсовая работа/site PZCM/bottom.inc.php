<td colspan="2" style="height:5%">
	<!-- Нижняя часть сайта --> 
	<table class="footer">
		<tr>
			<td>
				Последний визит: <?=$dateVisit?><br>
				Системное время: <?=date("d.m.Y H:i")?>
				<br/> Информация о сервере: <?=$_SERVER['SERVER_SOFTWARE']?>
			</td>
		</tr>
		<tr>
			<td>&copy; ОАО "Приокский завод цветных металлов"</td>	
		</tr>
	</table>
</td>